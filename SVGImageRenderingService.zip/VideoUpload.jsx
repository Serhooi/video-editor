import { useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { Upload, FileVideo, X } from 'lucide-react'
import { Button } from './ui/button'

export function VideoUpload({ onVideoUpload, uploadedVideos, onRemoveVideo }) {
  const onDrop = useCallback((acceptedFiles) => {
    acceptedFiles.forEach((file) => {
      if (file.type.startsWith('video/')) {
        const videoUrl = URL.createObjectURL(file)
        const video = {
          id: Date.now() + Math.random(),
          name: file.name,
          url: videoUrl,
          file: file,
          duration: 0,
          size: file.size
        }
        
        // Get video duration
        const videoElement = document.createElement('video')
        videoElement.src = videoUrl
        videoElement.onloadedmetadata = () => {
          video.duration = videoElement.duration
          onVideoUpload(video)
        }
      }
    })
  }, [onVideoUpload])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.mov', '.avi', '.mkv', '.webm']
    },
    multiple: true
  })

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
          isDragActive
            ? 'border-purple-500 bg-purple-500/10'
            : 'border-slate-600 hover:border-slate-500 bg-slate-800/30'
        }`}
      >
        <input {...getInputProps()} />
        <Upload className="w-8 h-8 mx-auto mb-3 text-gray-400" />
        {isDragActive ? (
          <p className="text-purple-400">Drop the videos here...</p>
        ) : (
          <div>
            <p className="text-gray-300 mb-1">Drag & drop videos here</p>
            <p className="text-sm text-gray-500">or click to browse</p>
          </div>
        )}
      </div>

      {uploadedVideos.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-gray-300">Uploaded Videos</h4>
          {uploadedVideos.map((video) => (
            <div
              key={video.id}
              className="flex items-center justify-between p-3 bg-slate-800/50 rounded border border-slate-600/50"
            >
              <div className="flex items-center space-x-3">
                <FileVideo className="w-4 h-4 text-blue-400" />
                <div>
                  <p className="text-sm text-gray-300 truncate max-w-32">{video.name}</p>
                  <p className="text-xs text-gray-500">
                    {formatFileSize(video.size)} • {formatDuration(video.duration)}
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onRemoveVideo(video.id)}
                className="text-gray-400 hover:text-red-400"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

