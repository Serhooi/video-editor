import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  Share, 
  Download, 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward,
  Volume2,
  Settings
} from 'lucide-react';

interface ModernHeaderProps {
  projectName: string;
  setProjectName: (name: string) => void;
  isPlaying?: boolean;
  onPlayPause?: () => void;
  onExport?: () => void;
  onShare?: () => void;
}

const ModernHeader: React.FC<ModernHeaderProps> = ({
  projectName,
  setProjectName,
  isPlaying = false,
  onPlayPause,
  onExport,
  onShare
}) => {
  return (
    <header className="header-modern">
      <div className="flex items-center gap-4">
        <div className="logo-modern">
          VideoEdit Pro
        </div>
        <div className="text-tertiary text-sm">
          /
        </div>
        <input
          type="text"
          value={projectName}
          onChange={(e) => setProjectName(e.target.value)}
          className="bg-transparent border-none outline-none text-primary font-medium text-sm min-w-0 flex-shrink"
          style={{ width: `${Math.max(projectName.length * 8, 120)}px` }}
        />
      </div>

      <div className="flex items-center gap-3">
        {/* Playback Controls */}
        <div className="flex items-center gap-2 px-3 py-1 bg-surface-secondary rounded-lg border border-border-primary">
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 hover:bg-surface-hover"
          >
            <SkipBack className="h-4 w-4" />
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 hover:bg-surface-hover"
            onClick={onPlayPause}
          >
            {isPlaying ? (
              <Pause className="h-4 w-4" />
            ) : (
              <Play className="h-4 w-4" />
            )}
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 hover:bg-surface-hover"
          >
            <SkipForward className="h-4 w-4" />
          </Button>
          
          <div className="w-px h-4 bg-border-primary mx-1" />
          
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 hover:bg-surface-hover"
          >
            <Volume2 className="h-4 w-4" />
          </Button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            className="btn-ghost"
            onClick={onShare}
          >
            <Share className="h-4 w-4 mr-2" />
            Share
          </Button>
          
          <Button
            className="btn-primary"
            size="sm"
            onClick={onExport}
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-8 p-0 hover:bg-surface-hover"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default ModernHeader;

