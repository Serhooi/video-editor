import { IAudio } from "@designcombo/types";

export const SOUND_EFFECTS: Partial<IAudio>[] = [
  {
    id: "sfx1",
    details: { src: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav" },
    type: "audio",
    metadata: {
      fileName: "Bell Ring",
      duration: "2s",
      category: "Notification",
    },
  },
  {
    id: "sfx2", 
    details: { src: "https://www.soundjay.com/misc/sounds/fail-buzzer-02.wav" },
    type: "audio",
    metadata: {
      fileName: "Buzzer Sound",
      duration: "1s",
      category: "Alert",
    },
  },
  {
    id: "sfx3",
    details: { src: "https://www.soundjay.com/misc/sounds/success-fanfare-trumpets.wav" },
    type: "audio", 
    metadata: {
      fileName: "Success Fanfare",
      duration: "3s",
      category: "Success",
    },
  },
  {
    id: "sfx4",
    details: { src: "https://www.soundjay.com/misc/sounds/click1.wav" },
    type: "audio",
    metadata: {
      fileName: "Click Sound",
      duration: "0.5s",
      category: "UI",
    },
  },
  {
    id: "sfx5",
    details: { src: "https://www.soundjay.com/misc/sounds/whoosh.wav" },
    type: "audio",
    metadata: {
      fileName: "Whoosh",
      duration: "1.5s",
      category: "Transition",
    },
  },
] as Partial<IAudio>[];

