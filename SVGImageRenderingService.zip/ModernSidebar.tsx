import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  Upload,
  Type,
  Image,
  Music,
  Sparkles,
  Scissors,
  Copy,
  Trash2,
  Layers,
  Filter,
  Palette,
  Volume2,
  Clock
} from 'lucide-react';

interface ModernSidebarProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
}

const ModernSidebar: React.FC<ModernSidebarProps> = ({
  activeTab = 'media',
  onTabChange
}) => {
  const toolGroups = [
    {
      title: 'Media',
      tools: [
        { id: 'upload', icon: Upload, label: 'Upload', shortcut: 'U' },
        { id: 'images', icon: Image, label: 'Images', shortcut: 'I' },
        { id: 'audio', icon: Music, label: 'Audio', shortcut: 'A' },
      ]
    },
    {
      title: 'Elements',
      tools: [
        { id: 'text', icon: Type, label: 'Text', shortcut: 'T' },
        { id: 'effects', icon: Sparkles, label: 'Effects', shortcut: 'E' },
        { id: 'filters', icon: Filter, label: 'Filters', shortcut: 'F' },
        { id: 'colors', icon: Palette, label: 'Colors', shortcut: 'C' },
      ]
    },
    {
      title: 'Edit',
      tools: [
        { id: 'split', icon: Scissors, label: 'Split', shortcut: 'S' },
        { id: 'copy', icon: Copy, label: 'Copy', shortcut: 'Ctrl+C' },
        { id: 'delete', icon: Trash2, label: 'Delete', shortcut: 'Del' },
        { id: 'layers', icon: Layers, label: 'Layers', shortcut: 'L' },
      ]
    },
    {
      title: 'Adjust',
      tools: [
        { id: 'volume', icon: Volume2, label: 'Volume', shortcut: 'V' },
        { id: 'timing', icon: Clock, label: 'Timing', shortcut: 'Shift+T' },
      ]
    }
  ];

  return (
    <aside className="sidebar-modern">
      {toolGroups.map((group) => (
        <div key={group.title} className="tool-group">
          <h3 className="tool-group-title">{group.title}</h3>
          <div className="space-y-1">
            {group.tools.map((tool) => {
              const Icon = tool.icon;
              const isActive = activeTab === tool.id;
              
              return (
                <button
                  key={tool.id}
                  className={`tool-button ${isActive ? 'active' : ''}`}
                  onClick={() => onTabChange?.(tool.id)}
                  title={`${tool.label} (${tool.shortcut})`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="flex-1 text-left">{tool.label}</span>
                  <span className="text-xs text-muted opacity-60">
                    {tool.shortcut}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      ))}
      
      {/* Quick Actions */}
      <div className="tool-group mt-auto">
        <h3 className="tool-group-title">Quick Actions</h3>
        <div className="space-y-2">
          <Button className="btn-primary w-full justify-start" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Upload Media
          </Button>
          <Button className="btn-secondary w-full justify-start" size="sm">
            <Type className="h-4 w-4 mr-2" />
            Add Text
          </Button>
        </div>
      </div>
    </aside>
  );
};

export default ModernSidebar;

