import Draggable from "@/components/shared/draggable";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileUploader } from "@/components/ui/file-uploader";
import { VIDEOS } from "../data/video";
import { dispatch } from "@designcombo/events";
import { ADD_VIDEO } from "@designcombo/state";
import { generateId } from "@designcombo/timeline";
import { IVideo } from "@designcombo/types";
import React, { useState } from "react";
import { useIsDraggingOverTimeline } from "../hooks/is-dragging-over-timeline";

export const Videos = () => {
  const isDraggingOverTimeline = useIsDraggingOverTimeline();
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);

  const handleAddVideo = (payload: Partial<IVideo>) => {
    // payload.details.src = "https://cdn.designcombo.dev/videos/timer-20s.mp4";
    dispatch(ADD_VIDEO, {
      payload,
      options: {
        resourceId: "main",
        scaleMode: "fit",
      },
    });
  };

  const handleFileUpload = (files: File[]) => {
    setUploadedFiles(files);
    
    files.forEach((file) => {
      // Create object URL for preview
      const objectUrl = URL.createObjectURL(file);
      
      // Add video to timeline
      handleAddVideo({
        id: generateId(),
        details: {
          src: objectUrl,
        },
        metadata: {
          previewUrl: objectUrl,
          fileName: file.name,
        },
      } as unknown as Partial<IVideo>);
    });
  };

  return (
    <div className="flex flex-1 flex-col">
      <div className="text-text-primary flex h-12 flex-none items-center px-4 text-sm font-medium">
        Videos
      </div>
      <ScrollArea className="flex-1 h-[calc(100vh-200px)]">
        <div className="px-4 space-y-4">
          {/* File Upload Section */}
          <div className="mb-4">
            <FileUploader
              value={uploadedFiles}
              onValueChange={handleFileUpload}
              accept={{
                "video/*": [".mp4", ".mov", ".avi", ".mkv", ".webm"],
              }}
              maxSize={50 * 1024 * 1024} // 50MB
              maxFileCount={5}
              multiple={true}
              className="h-32"
            />
          </div>
          
          {/* Existing Videos */}
          <div className="masonry-sm">
            {VIDEOS.map((video, index) => {
              return (
                <VideoItem
                  key={index}
                  video={video}
                  shouldDisplayPreview={!isDraggingOverTimeline}
                  handleAddImage={handleAddVideo}
                />
              );
            })}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

const VideoItem = ({
  handleAddImage,
  video,
  shouldDisplayPreview,
}: {
  handleAddImage: (payload: Partial<IVideo>) => void;
  video: Partial<IVideo>;
  shouldDisplayPreview: boolean;
}) => {
  const style = React.useMemo(
    () => ({
      backgroundImage: `url(${video.preview})`,
      backgroundSize: "cover",
      width: "80px",
      height: "80px",
    }),
    [video.preview],
  );

  return (
    <Draggable
      data={{
        ...video,
        metadata: {
          previewUrl: video.preview,
        },
      }}
      renderCustomPreview={<div style={style} className="draggable" />}
      shouldDisplayPreview={shouldDisplayPreview}
    >
      <div
        onClick={() =>
          handleAddImage({
            id: generateId(),
            details: {
              src: video.details!.src,
            },
            metadata: {
              previewUrl: video.preview,
            },
          } as any)
        }
        className="flex w-full items-center justify-center overflow-hidden bg-background pb-2"
      >
        <img
          draggable={false}
          src={video.preview}
          className="h-full w-full rounded-md object-cover"
          alt="image"
        />
      </div>
    </Draggable>
  );
};
