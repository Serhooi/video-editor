import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  RotateCcw,
  RotateCw,
  ZoomIn,
  ZoomOut,
  Monitor,
  Smartphone,
  Square,
  Tablet
} from 'lucide-react';

interface ModernPreviewProps {
  isPlaying?: boolean;
  currentTime?: number;
  duration?: number;
  volume?: number;
  aspectRatio?: string;
  onPlayPause?: () => void;
  onVolumeChange?: (volume: number) => void;
  onSeek?: (time: number) => void;
  onAspectRatioChange?: (ratio: string) => void;
}

const ModernPreview: React.FC<ModernPreviewProps> = ({
  isPlaying = false,
  currentTime = 0,
  duration = 100,
  volume = 50,
  aspectRatio = '16:9',
  onPlayPause,
  onVolumeChange,
  onSeek,
  onAspectRatioChange
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [zoom, setZoom] = useState(100);

  const aspectRatios = [
    { id: '16:9', label: 'Landscape', icon: Monitor, width: '16', height: '9' },
    { id: '9:16', label: 'Portrait', icon: Smartphone, width: '9', height: '16' },
    { id: '1:1', label: 'Square', icon: Square, width: '1', height: '1' },
    { id: '4:3', label: 'Classic', icon: Tablet, width: '4', height: '3' },
  ];

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getPreviewDimensions = () => {
    const maxWidth = 640;
    const maxHeight = 480;
    
    switch (aspectRatio) {
      case '16:9':
        return { width: maxWidth, height: maxWidth * 9 / 16 };
      case '9:16':
        return { width: maxHeight * 9 / 16, height: maxHeight };
      case '1:1':
        return { width: Math.min(maxWidth, maxHeight), height: Math.min(maxWidth, maxHeight) };
      case '4:3':
        return { width: maxWidth, height: maxWidth * 3 / 4 };
      default:
        return { width: maxWidth, height: maxWidth * 9 / 16 };
    }
  };

  const dimensions = getPreviewDimensions();

  return (
    <div className="preview-modern">
      <div className="flex flex-col items-center gap-6 w-full max-w-4xl">
        {/* Aspect Ratio Selector */}
        <div className="flex items-center gap-2 p-1 bg-surface-secondary rounded-lg border border-border-primary">
          {aspectRatios.map((ratio) => {
            const Icon = ratio.icon;
            const isActive = aspectRatio === ratio.id;
            
            return (
              <button
                key={ratio.id}
                className={`flex items-center gap-2 px-3 py-2 rounded-md transition-all ${
                  isActive 
                    ? 'bg-brand-primary text-white' 
                    : 'text-secondary hover:bg-surface-hover hover:text-primary'
                }`}
                onClick={() => onAspectRatioChange?.(ratio.id)}
              >
                <Icon className="h-4 w-4" />
                <span className="text-sm font-medium">{ratio.label}</span>
                <span className="text-xs opacity-60">{ratio.id}</span>
              </button>
            );
          })}
        </div>

        {/* Preview Container */}
        <div className="preview-container">
          <div 
            className="relative bg-black rounded-lg overflow-hidden"
            style={{ 
              width: dimensions.width * (zoom / 100), 
              height: dimensions.height * (zoom / 100),
              transition: 'all 0.3s ease'
            }}
          >
            {/* Video Preview Area */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center text-muted">
                <Monitor className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Video Preview</p>
                <p className="text-xs opacity-60">{aspectRatio} • {zoom}%</p>
              </div>
            </div>

            {/* Play Button Overlay */}
            {!isPlaying && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Button
                  className="control-button primary"
                  onClick={onPlayPause}
                >
                  <Play className="h-6 w-6" />
                </Button>
              </div>
            )}
          </div>

          {/* Preview Controls */}
          <div className="flex items-center justify-between mt-4 px-2">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => setZoom(Math.max(25, zoom - 25))}
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <span className="text-sm text-secondary min-w-12 text-center">
                {zoom}%
              </span>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => setZoom(Math.min(200, zoom + 25))}
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <RotateCcw className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <RotateCw className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <Maximize className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Playback Controls */}
        <div className="controls-modern w-full">
          {/* Progress Bar */}
          <div className="progress-modern mb-4">
            <div 
              className="progress-fill"
              style={{ width: `${(currentTime / duration) * 100}%` }}
            />
          </div>

          {/* Control Buttons */}
          <div className="playback-controls">
            <Button
              className={`control-button ${isPlaying ? '' : 'primary'}`}
              onClick={onPlayPause}
            >
              {isPlaying ? (
                <Pause className="h-5 w-5" />
              ) : (
                <Play className="h-5 w-5" />
              )}
            </Button>

            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => setIsMuted(!isMuted)}
              >
                {isMuted ? (
                  <VolumeX className="h-4 w-4" />
                ) : (
                  <Volume2 className="h-4 w-4" />
                )}
              </Button>
              
              <input
                type="range"
                min="0"
                max="100"
                value={isMuted ? 0 : volume}
                onChange={(e) => onVolumeChange?.(Number(e.target.value))}
                className="slider-modern w-20"
              />
            </div>

            <div className="text-sm text-secondary">
              {formatTime(currentTime)} / {formatTime(duration)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModernPreview;

