import { useState } from 'react'
import { Type, Plus, Trash2, AlignLeft, AlignCenter, AlignRight, Bold, Italic, Underline } from 'lucide-react'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Slider } from './ui/slider'
import { v4 as uuidv4 } from 'uuid'

export function TextEditor({ textElements, setTextElements, onAddToTimeline }) {
  const [selectedElement, setSelectedElement] = useState(null)

  const textStyles = [
    { id: 'heading', name: 'Heading', fontSize: 48, fontWeight: 'bold', color: '#ffffff' },
    { id: 'subtitle', name: 'Subtitle', fontSize: 32, fontWeight: 'semibold', color: '#e5e7eb' },
    { id: 'body', name: 'Body', fontSize: 24, fontWeight: 'normal', color: '#d1d5db' },
    { id: 'caption', name: 'Caption', fontSize: 18, fontWeight: 'normal', color: '#9ca3af' }
  ]

  const alignments = [
    { id: 'left', icon: AlignLeft, value: 'left' },
    { id: 'center', icon: AlignCenter, value: 'center' },
    { id: 'right', icon: AlignRight, value: 'right' }
  ]

  const createTextElement = (style) => {
    const newElement = {
      id: uuidv4(),
      text: 'Your text here',
      style: style.id,
      fontSize: style.fontSize,
      fontWeight: style.fontWeight,
      color: style.color,
      alignment: 'center',
      x: 50,
      y: 50,
      duration: 5,
      start: 0,
      bold: false,
      italic: false,
      underline: false,
      backgroundColor: 'transparent',
      borderColor: 'transparent',
      borderWidth: 0,
      opacity: 100,
      rotation: 0
    }
    
    setTextElements(prev => [...prev, newElement])
    setSelectedElement(newElement)
  }

  const updateElement = (id, updates) => {
    setTextElements(prev => 
      prev.map(el => el.id === id ? { ...el, ...updates } : el)
    )
    if (selectedElement?.id === id) {
      setSelectedElement(prev => ({ ...prev, ...updates }))
    }
  }

  const deleteElement = (id) => {
    setTextElements(prev => prev.filter(el => el.id !== id))
    if (selectedElement?.id === id) {
      setSelectedElement(null)
    }
  }

  const addToTimeline = (element) => {
    const track = {
      id: Date.now() + Math.random(),
      type: 'text',
      name: element.text.substring(0, 20) + (element.text.length > 20 ? '...' : ''),
      color: 'bg-purple-500',
      duration: element.duration,
      start: element.start,
      data: element
    }
    onAddToTimeline(track)
  }

  return (
    <div className="space-y-4">
      {/* Add Text Button */}
      <Button 
        className="w-full bg-orange-500 hover:bg-orange-600 text-white"
        onClick={() => createTextElement(textStyles[0])}
      >
        <Type className="w-4 h-4 mr-2" />
        Add Text
      </Button>

      {/* Text Styles */}
      <div className="space-y-2">
        <h4 className="text-sm font-medium text-gray-300">Text Styles</h4>
        {textStyles.map((style) => (
          <button
            key={style.id}
            onClick={() => createTextElement(style)}
            className="w-full p-2 text-left text-sm bg-slate-800/50 hover:bg-slate-700/50 rounded border border-slate-600/50 text-gray-300 transition-colors"
          >
            <span style={{ fontSize: `${Math.min(style.fontSize / 2, 16)}px`, fontWeight: style.fontWeight }}>
              {style.name}
            </span>
          </button>
        ))}
      </div>

      {/* Text Elements List */}
      {textElements.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-gray-300">Text Elements</h4>
          {textElements.map((element) => (
            <div
              key={element.id}
              className={`p-2 rounded border cursor-pointer transition-colors ${
                selectedElement?.id === element.id
                  ? 'border-purple-500 bg-purple-500/10'
                  : 'border-slate-600/50 bg-slate-800/50 hover:bg-slate-700/50'
              }`}
              onClick={() => setSelectedElement(element)}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-300 truncate flex-1">
                  {element.text}
                </span>
                <div className="flex space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation()
                      addToTimeline(element)
                    }}
                    className="h-6 w-6 p-0 text-green-400 hover:text-green-300"
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation()
                      deleteElement(element.id)
                    }}
                    className="h-6 w-6 p-0 text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Text Editor */}
      {selectedElement && (
        <div className="space-y-4 border-t border-slate-700/50 pt-4">
          <h4 className="text-sm font-medium text-gray-300">Edit Text</h4>
          
          {/* Text Content */}
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Text</label>
            <Input
              value={selectedElement.text}
              onChange={(e) => updateElement(selectedElement.id, { text: e.target.value })}
              className="bg-slate-800/50 border-slate-600/50 text-gray-300"
              placeholder="Enter your text"
            />
          </div>

          {/* Font Size */}
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Font Size: {selectedElement.fontSize}px</label>
            <Slider
              value={[selectedElement.fontSize]}
              onValueChange={(value) => updateElement(selectedElement.id, { fontSize: value[0] })}
              min={12}
              max={72}
              step={1}
              className="w-full"
            />
          </div>

          {/* Text Formatting */}
          <div>
            <label className="text-xs text-gray-500 mb-2 block">Formatting</label>
            <div className="flex space-x-1">
              <Button
                variant={selectedElement.bold ? "default" : "ghost"}
                size="sm"
                onClick={() => updateElement(selectedElement.id, { bold: !selectedElement.bold })}
                className="text-gray-300"
              >
                <Bold className="w-4 h-4" />
              </Button>
              <Button
                variant={selectedElement.italic ? "default" : "ghost"}
                size="sm"
                onClick={() => updateElement(selectedElement.id, { italic: !selectedElement.italic })}
                className="text-gray-300"
              >
                <Italic className="w-4 h-4" />
              </Button>
              <Button
                variant={selectedElement.underline ? "default" : "ghost"}
                size="sm"
                onClick={() => updateElement(selectedElement.id, { underline: !selectedElement.underline })}
                className="text-gray-300"
              >
                <Underline className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Text Alignment */}
          <div>
            <label className="text-xs text-gray-500 mb-2 block">Alignment</label>
            <div className="flex space-x-1">
              {alignments.map((align) => (
                <Button
                  key={align.id}
                  variant={selectedElement.alignment === align.value ? "default" : "ghost"}
                  size="sm"
                  onClick={() => updateElement(selectedElement.id, { alignment: align.value })}
                  className="text-gray-300"
                >
                  <align.icon className="w-4 h-4" />
                </Button>
              ))}
            </div>
          </div>

          {/* Color */}
          <div>
            <label className="text-xs text-gray-500 mb-1 block">Text Color</label>
            <input
              type="color"
              value={selectedElement.color}
              onChange={(e) => updateElement(selectedElement.id, { color: e.target.value })}
              className="w-full h-8 rounded border border-slate-600/50 bg-slate-800/50"
            />
          </div>

          {/* Position */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-500 mb-1 block">X Position: {selectedElement.x}%</label>
              <Slider
                value={[selectedElement.x]}
                onValueChange={(value) => updateElement(selectedElement.id, { x: value[0] })}
                min={0}
                max={100}
                step={1}
                className="w-full"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Y Position: {selectedElement.y}%</label>
              <Slider
                value={[selectedElement.y]}
                onValueChange={(value) => updateElement(selectedElement.id, { y: value[0] })}
                min={0}
                max={100}
                step={1}
                className="w-full"
              />
            </div>
          </div>

          {/* Duration and Start Time */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Duration: {selectedElement.duration}s</label>
              <Slider
                value={[selectedElement.duration]}
                onValueChange={(value) => updateElement(selectedElement.id, { duration: value[0] })}
                min={0.5}
                max={30}
                step={0.5}
                className="w-full"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Start: {selectedElement.start}s</label>
              <Slider
                value={[selectedElement.start]}
                onValueChange={(value) => updateElement(selectedElement.id, { start: value[0] })}
                min={0}
                max={60}
                step={0.5}
                className="w-full"
              />
            </div>
          </div>

          {/* Add to Timeline Button */}
          <Button
            onClick={() => addToTimeline(selectedElement)}
            className="w-full bg-green-500 hover:bg-green-600 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add to Timeline
          </Button>
        </div>
      )}
    </div>
  )
}

