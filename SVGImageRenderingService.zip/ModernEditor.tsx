import React, { useState, useEffect } from 'react';
import ModernHeader from './ModernHeader';
import ModernSidebar from './ModernSidebar';
import ModernPreview from './ModernPreview';
import ModernTimeline from './ModernTimeline';

interface ModernEditorProps {
  // Можно добавить пропсы для интеграции с существующим кодом
}

const ModernEditor: React.FC<ModernEditorProps> = () => {
  const [projectName, setProjectName] = useState('Untitled video');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(120);
  const [volume, setVolume] = useState(50);
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [activeTab, setActiveTab] = useState('upload');
  const [timelineZoom, setTimelineZoom] = useState(1);

  // Симуляция воспроизведения
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          if (prev >= duration) {
            setIsPlaying(false);
            return duration;
          }
          return prev + 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, duration]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (time: number) => {
    setCurrentTime(time);
  };

  const handleExport = () => {
    console.log('Exporting video...');
    // Здесь будет интеграция с существующей логикой экспорта
  };

  const handleShare = () => {
    console.log('Sharing video...');
    // Здесь будет интеграция с существующей логикой шеринга
  };

  return (
    <div className="flex h-screen w-screen flex-col bg-primary text-primary">
      {/* Modern Header */}
      <ModernHeader
        projectName={projectName}
        setProjectName={setProjectName}
        isPlaying={isPlaying}
        onPlayPause={handlePlayPause}
        onExport={handleExport}
        onShare={handleShare}
      />

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Modern Sidebar */}
        <ModernSidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />

        {/* Content Area */}
        <div className="flex-1 flex flex-col">
          {/* Preview Area */}
          <div className="flex-1 min-h-0">
            <ModernPreview
              isPlaying={isPlaying}
              currentTime={currentTime}
              duration={duration}
              volume={volume}
              aspectRatio={aspectRatio}
              onPlayPause={handlePlayPause}
              onVolumeChange={setVolume}
              onSeek={handleSeek}
              onAspectRatioChange={setAspectRatio}
            />
          </div>

          {/* Timeline Area */}
          <div className="h-80 border-t border-border-primary">
            <ModernTimeline
              currentTime={currentTime}
              duration={duration}
              zoom={timelineZoom}
              isPlaying={isPlaying}
              onPlayPause={handlePlayPause}
              onSeek={handleSeek}
              onZoomChange={setTimelineZoom}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModernEditor;

