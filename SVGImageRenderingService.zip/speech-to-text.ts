// Типы для Web Speech API
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

interface Word {
  word: string;
  start: number;
  end: number;
  confidence: number;
}

interface SpeechToTextResult {
  words: Word[];
}

// Web Speech API implementation
export class WebSpeechToText {
  private recognition: any | null = null;
  private isSupported: boolean = false;

  constructor() {
    // Check if Web Speech API is supported
    const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.isSupported = true;
      this.setupRecognition();
    }
  }

  private setupRecognition() {
    if (!this.recognition) return;

    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';
  }

  async transcribeAudio(audioBlob: Blob): Promise<SpeechToTextResult> {
    if (!this.isSupported || !this.recognition) {
      throw new Error('Web Speech API is not supported in this browser');
    }

    return new Promise((resolve, reject) => {
      const words: Word[] = [];
      let startTime = 0;
      let wordIndex = 0;

      this.recognition!.onresult = (event) => {
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          if (result.isFinal) {
            const transcript = result[0].transcript.trim();
            const wordsArray = transcript.split(' ');
            
            // Estimate timing for each word (simplified approach)
            const duration = 3; // Assume 3 seconds for demo
            const wordDuration = duration / wordsArray.length;

            wordsArray.forEach((word, index) => {
              words.push({
                word: word,
                start: startTime + (index * wordDuration),
                end: startTime + ((index + 1) * wordDuration),
                confidence: result[0].confidence || 0.9
              });
            });

            startTime += duration;
          }
        }
      };

      this.recognition!.onerror = (event) => {
        reject(new Error(`Speech recognition error: ${event.error}`));
      };

      this.recognition!.onend = () => {
        resolve({ words });
      };

      // For demo purposes, we'll simulate transcription
      // In real implementation, you'd need to convert audio blob to stream
      setTimeout(() => {
        // Simulate some transcribed words
        const demoWords: Word[] = [
          { word: "Hello", start: 0, end: 0.5, confidence: 0.95 },
          { word: "world", start: 0.5, end: 1.0, confidence: 0.92 },
          { word: "this", start: 1.0, end: 1.3, confidence: 0.88 },
          { word: "is", start: 1.3, end: 1.5, confidence: 0.94 },
          { word: "auto", start: 1.5, end: 1.8, confidence: 0.91 },
          { word: "generated", start: 1.8, end: 2.5, confidence: 0.89 },
          { word: "subtitles", start: 2.5, end: 3.2, confidence: 0.93 }
        ];
        resolve({ words: demoWords });
      }, 1000);
    });
  }

  isWebSpeechSupported(): boolean {
    return this.isSupported;
  }
}

// Alternative implementation using OpenAI Whisper API
export class WhisperSpeechToText {
  private apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async transcribeAudio(audioBlob: Blob): Promise<SpeechToTextResult> {
    const formData = new FormData();
    formData.append('file', audioBlob, 'audio.wav');
    formData.append('model', 'whisper-1');
    formData.append('response_format', 'verbose_json');
    formData.append('timestamp_granularities[]', 'word');

    try {
      const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Whisper API error: ${response.statusText}`);
      }

      const result = await response.json();
      
      // Convert Whisper format to our format
      const words: Word[] = result.words?.map((word: any) => ({
        word: word.word,
        start: word.start,
        end: word.end,
        confidence: 1.0 // Whisper doesn't provide confidence scores
      })) || [];

      return { words };
    } catch (error) {
      throw new Error(`Failed to transcribe audio: ${error}`);
    }
  }
}

// Factory function to create appropriate speech-to-text service
export function createSpeechToTextService(options?: { openaiApiKey?: string }) {
  if (options?.openaiApiKey) {
    return new WhisperSpeechToText(options.openaiApiKey);
  }
  
  return new WebSpeechToText();
}

// Utility function to extract audio from video
export async function extractAudioFromVideo(videoFile: File): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    video.onloadedmetadata = () => {
      // Create audio context for audio extraction
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const source = audioContext.createMediaElementSource(video);
      const destination = audioContext.createMediaStreamDestination();
      
      source.connect(destination);
      
      const mediaRecorder = new MediaRecorder(destination.stream);
      const chunks: Blob[] = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(chunks, { type: 'audio/wav' });
        resolve(audioBlob);
      };

      mediaRecorder.start();
      video.play();

      video.onended = () => {
        mediaRecorder.stop();
      };
    };

    video.onerror = () => {
      reject(new Error('Failed to load video'));
    };

    video.src = URL.createObjectURL(videoFile);
  });
}

