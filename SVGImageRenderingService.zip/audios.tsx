import { ScrollArea } from "@/components/ui/scroll-area";
import { FileUploader } from "@/components/ui/file-uploader";
import { SOUND_EFFECTS } from "../data/audios";
import { dispatch } from "@designcombo/events";
import { ADD_ITEMS } from "@designcombo/state";
import { generateId } from "@designcombo/timeline";
import { IAudio } from "@designcombo/types";
import React, { useState } from "react";
import { useIsDraggingOverTimeline } from "../hooks/is-dragging-over-timeline";
import Draggable from "@/components/shared/draggable";
import { Icons } from "@/components/shared/icons";

export const Audios = () => {
  const isDraggingOverTimeline = useIsDraggingOverTimeline();
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);

  const handleAddAudio = (payload: Partial<IAudio>) => {
    const id = generateId();
    dispatch(ADD_ITEMS, {
      payload: {
        trackItems: [
          {
            id,
            type: "audio",
            display: {
              from: 0,
              to: 30000, // 30 seconds default
            },
            details: {
              src: payload.details?.src,
            },
            metadata: payload.metadata || {},
          },
        ],
      },
    });
  };

  const handleFileUpload = (files: File[]) => {
    setUploadedFiles(files);
    
    files.forEach((file) => {
      // Create object URL for preview
      const objectUrl = URL.createObjectURL(file);
      
      // Add audio to timeline
      handleAddAudio({
        id: generateId(),
        details: {
          src: objectUrl,
        },
        metadata: {
          fileName: file.name,
        },
      } as Partial<IAudio>);
    });
  };

  return (
    <div className="flex flex-1 flex-col">
      <div className="text-text-primary flex h-12 flex-none items-center px-4 text-sm font-medium">
        Audio
      </div>
      <ScrollArea>
        <div className="px-4 space-y-4">
          {/* File Upload Section */}
          <div className="mb-4">
            <FileUploader
              value={uploadedFiles}
              onValueChange={handleFileUpload}
              accept={{
                "audio/*": [".mp3", ".wav", ".ogg", ".m4a", ".aac"],
              }}
              maxSize={20 * 1024 * 1024} // 20MB
              maxFileCount={5}
              multiple={true}
              className="h-32"
            />
          </div>
          
          {/* Existing Audio Files */}
          <div className="space-y-2">
            {SOUND_EFFECTS.map((audio, index) => {
              return (
                <AudioItem
                  key={index}
                  audio={audio}
                  shouldDisplayPreview={!isDraggingOverTimeline}
                  handleAddAudio={handleAddAudio}
                />
              );
            })}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

const AudioItem = ({
  handleAddAudio,
  audio,
  shouldDisplayPreview,
}: {
  handleAddAudio: (payload: Partial<IAudio>) => void;
  audio: Partial<IAudio>;
  shouldDisplayPreview: boolean;
}) => {
  return (
    <Draggable
      data={audio}
      renderCustomPreview={
        <div className="flex items-center gap-2 bg-background p-2 rounded">
          <Icons.audio className="w-4 h-4" />
          <span className="text-sm">{audio.metadata?.fileName || "Audio"}</span>
        </div>
      }
      shouldDisplayPreview={shouldDisplayPreview}
    >
      <div
        onClick={() =>
          handleAddAudio({
            id: generateId(),
            details: {
              src: audio.details!.src,
            },
            metadata: audio.metadata,
          } as IAudio)
        }
        className="flex items-center gap-3 p-3 rounded-md bg-background hover:bg-muted cursor-pointer transition-colors"
      >
        <div className="flex-shrink-0">
          <Icons.audio className="w-6 h-6 text-muted-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">
            {audio.metadata?.fileName || "Audio Track"}
          </p>
          <p className="text-xs text-muted-foreground">
            {audio.metadata?.duration || "Unknown duration"}
          </p>
        </div>
      </div>
    </Draggable>
  );
};

