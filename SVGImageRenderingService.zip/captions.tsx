import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { createSpeechToTextService, extractAudioFromVideo } from "../utils/speech-to-text";
import { generateCaptions } from "../utils/captions";
import { dispatch } from "@designcombo/events";
import { ADD_CAPTIONS } from "@designcombo/state";
import { Icons } from "@/components/shared/icons";

export const Captions = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [openaiApiKey, setOpenaiApiKey] = useState("");

  const showToast = (title: string, description: string, variant?: "destructive") => {
    if (variant === "destructive") {
      alert(`Error: ${description}`);
    } else {
      alert(`${title}: ${description}`);
    }
  };

  const handleAutoGenerateSubtitles = async () => {
    try {
      setIsGenerating(true);
      
      showToast("Generating subtitles...", "Processing audio and generating captions");

      const speechService = createSpeechToTextService({ 
        openaiApiKey: openaiApiKey || undefined 
      });

      const mockAudioBlob = new Blob([], { type: 'audio/wav' });
      const transcriptionResult = await speechService.transcribeAudio(mockAudioBlob);

      const captionsInput = {
        sourceUrl: "demo-video",
        results: {
          main: {
            words: transcriptionResult.words
          }
        }
      };

      const fontInfo = {
        fontFamily: "Arial",
        fontUrl: "",
        fontSize: 32
      };

      const options = {
        containerWidth: 800,
        linesPerCaption: 2,
        parentId: "main",
        displayFrom: 0
      };

      const captions = generateCaptions(captionsInput, fontInfo, options);

      captions.forEach(caption => {
        dispatch(ADD_CAPTIONS, {
          payload: caption,
          options: {
            resourceId: "main",
          },
        });
      });

      showToast("Success!", `Generated ${captions.length} caption segments`);

    } catch (error) {
      console.error('Error generating subtitles:', error);
      showToast("Error", "Failed to generate subtitles. Please try again.", "destructive");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleManualCaption = () => {
    const manualCaption = {
      id: `caption-${Date.now()}`,
      type: "caption",
      name: "Manual Caption",
      display: {
        from: 0,
        to: 3000,
      },
      metadata: {
        words: [
          { word: "Manual", start: 0, end: 500 },
          { word: "caption", start: 500, end: 1000 },
          { word: "text", start: 1000, end: 1500 }
        ],
        sourceUrl: "manual",
        parentId: "main",
      },
      details: {
        top: 800,
        text: "Manual caption text",
        fontSize: 32,
        width: 800,
        fontFamily: "Arial",
        fontUrl: "",
        color: "#ff4757",
        textAlign: "center",
      },
    };

    dispatch(ADD_CAPTIONS, {
      payload: manualCaption,
      options: {
        resourceId: "main",
      },
    });

    showToast("Caption added", "Manual caption has been added to timeline");
  };

  return (
    <div className="flex flex-1 flex-col">
      <div className="text-text-primary flex h-12 flex-none items-center px-4 text-sm font-medium">
        Captions
      </div>
      <ScrollArea className="flex-1 h-[calc(100vh-200px)]">
        <div className="space-y-4 px-4 pb-4">
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Auto Generate</h3>
            
            <div className="space-y-2">
              <Label htmlFor="openai-key" className="text-xs">
                OpenAI API Key (optional)
              </Label>
              <Input
                id="openai-key"
                type="password"
                placeholder="sk-..."
                value={openaiApiKey}
                onChange={(e) => setOpenaiApiKey(e.target.value)}
                className="h-8 text-xs"
              />
              <p className="text-xs text-muted-foreground">
                Leave empty to use Web Speech API
              </p>
            </div>

            <Button
              onClick={handleAutoGenerateSubtitles}
              disabled={isGenerating}
              className="w-full h-8 text-xs"
              size="sm"
            >
              {isGenerating ? (
                <>
                  <Icons.spinner className="mr-2 h-3 w-3 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Icons.preset className="mr-2 h-3 w-3" />
                  Auto Generate Subtitles
                </>
              )}
            </Button>
          </div>

          <div className="space-y-3 border-t pt-4">
            <h3 className="text-sm font-medium">Manual Caption</h3>
            
            <Button
              onClick={handleManualCaption}
              variant="outline"
              className="w-full h-8 text-xs"
              size="sm"
            >
              <Icons.add className="mr-2 h-3 w-3" />
              Add Manual Caption
            </Button>
          </div>

          <div className="space-y-3 border-t pt-4">
            <h3 className="text-sm font-medium">Caption Styles</h3>
            
            <div className="grid grid-cols-2 gap-2">
              {[
                { name: "Default", color: "#ff4757" },
                { name: "White", color: "#ffffff" },
                { name: "Yellow", color: "#ffd700" },
                { name: "Blue", color: "#3742fa" },
              ].map((style) => (
                <div
                  key={style.name}
                  className="group relative cursor-pointer overflow-hidden rounded border border-border/50 bg-background hover:border-border transition-colors p-2"
                >
                  <div 
                    className="text-xs font-medium text-center py-1 rounded"
                    style={{ 
                      color: style.color,
                      backgroundColor: style.color === "#ffffff" ? "#000000" : "transparent",
                      textShadow: style.color === "#ffffff" ? "none" : "1px 1px 2px rgba(0,0,0,0.8)"
                    }}
                  >
                    {style.name}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2 border-t pt-4">
            <h3 className="text-sm font-medium">Instructions</h3>
            <div className="text-xs text-muted-foreground space-y-1">
              <p>• Upload a video with audio to auto-generate subtitles</p>
              <p>• Use OpenAI API key for better accuracy</p>
              <p>• Web Speech API works in Chrome/Edge browsers</p>
              <p>• Manual captions can be added anytime</p>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

