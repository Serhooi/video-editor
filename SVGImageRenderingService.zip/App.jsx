import VideoEditor from './components/VideoEditor.jsx'
import './App.css'

function App() {
  return <VideoEditor />
}

export default App

