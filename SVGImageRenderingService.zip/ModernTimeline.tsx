import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Scissors,
  Copy,
  Trash2,
  Plus,
  ZoomIn,
  ZoomOut,
  Move,
  Lock,
  Eye,
  EyeOff
} from 'lucide-react';

interface TimelineTrack {
  id: string;
  type: 'video' | 'audio' | 'text' | 'effect';
  name: string;
  duration: number;
  startTime: number;
  isLocked?: boolean;
  isVisible?: boolean;
  isMuted?: boolean;
}

interface ModernTimelineProps {
  tracks?: TimelineTrack[];
  currentTime?: number;
  duration?: number;
  zoom?: number;
  isPlaying?: boolean;
  onPlayPause?: () => void;
  onSeek?: (time: number) => void;
  onZoomChange?: (zoom: number) => void;
  onTrackUpdate?: (trackId: string, updates: Partial<TimelineTrack>) => void;
}

const ModernTimeline: React.FC<ModernTimelineProps> = ({
  tracks = [],
  currentTime = 0,
  duration = 100,
  zoom = 1,
  isPlaying = false,
  onPlayPause,
  onSeek,
  onZoomChange,
  onTrackUpdate
}) => {
  const [selectedTrack, setSelectedTrack] = useState<string | null>(null);

  const trackTypeColors = {
    video: 'var(--timeline-video)',
    audio: 'var(--timeline-audio)',
    text: 'var(--timeline-text)',
    effect: 'var(--timeline-effect)'
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getTrackWidth = (trackDuration: number) => {
    return (trackDuration / duration) * 100 * zoom;
  };

  const getTrackPosition = (startTime: number) => {
    return (startTime / duration) * 100 * zoom;
  };

  const defaultTracks: TimelineTrack[] = [
    {
      id: 'video-1',
      type: 'video',
      name: 'Main Video',
      duration: 60,
      startTime: 0,
      isVisible: true,
      isLocked: false
    },
    {
      id: 'text-1',
      type: 'text',
      name: 'Heading and some body',
      duration: 30,
      startTime: 10,
      isVisible: true,
      isLocked: false
    },
    {
      id: 'audio-1',
      type: 'audio',
      name: 'Background Music',
      duration: 80,
      startTime: 0,
      isVisible: true,
      isLocked: false,
      isMuted: false
    }
  ];

  const displayTracks = tracks.length > 0 ? tracks : defaultTracks;

  return (
    <div className="timeline-modern">
      {/* Timeline Header */}
      <div className="flex items-center justify-between mb-4 pb-4 border-b border-border-primary">
        <div className="flex items-center gap-4">
          <h3 className="text-lg font-semibold text-primary">Timeline</h3>
          <div className="text-sm text-secondary">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Zoom Controls */}
          <div className="flex items-center gap-1 px-2 py-1 bg-surface-secondary rounded-md border border-border-primary">
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={() => onZoomChange?.(Math.max(0.25, zoom - 0.25))}
            >
              <ZoomOut className="h-3 w-3" />
            </Button>
            <span className="text-xs text-secondary min-w-12 text-center">
              {Math.round(zoom * 100)}%
            </span>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={() => onZoomChange?.(Math.min(4, zoom + 0.25))}
            >
              <ZoomIn className="h-3 w-3" />
            </Button>
          </div>

          {/* Playback Controls */}
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <SkipBack className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
              onClick={onPlayPause}
            >
              {isPlaying ? (
                <Pause className="h-4 w-4" />
              ) : (
                <Play className="h-4 w-4" />
              )}
            </Button>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <SkipForward className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Timeline Ruler */}
      <div className="relative mb-4">
        <div className="h-8 bg-surface-secondary rounded-md border border-border-primary relative overflow-hidden">
          {/* Time markers */}
          {Array.from({ length: Math.ceil(duration / 10) + 1 }, (_, i) => (
            <div
              key={i}
              className="absolute top-0 h-full flex items-center"
              style={{ left: `${(i * 10 / duration) * 100 * zoom}%` }}
            >
              <div className="w-px h-4 bg-border-secondary" />
              <span className="text-xs text-tertiary ml-1">
                {formatTime(i * 10)}
              </span>
            </div>
          ))}
          
          {/* Playhead */}
          <div
            className="absolute top-0 w-0.5 h-full bg-brand-primary z-10"
            style={{ left: `${(currentTime / duration) * 100 * zoom}%` }}
          >
            <div className="absolute -top-1 -left-1 w-3 h-3 bg-brand-primary rounded-full" />
          </div>
        </div>
      </div>

      {/* Tracks */}
      <div className="space-y-2">
        {displayTracks.map((track) => (
          <div
            key={track.id}
            className={`timeline-track ${track.type} ${
              selectedTrack === track.id ? 'ring-2 ring-brand-primary' : ''
            }`}
            onClick={() => setSelectedTrack(track.id)}
          >
            <div className="flex items-center p-3">
              {/* Track Controls */}
              <div className="flex items-center gap-2 w-48 flex-shrink-0">
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => onTrackUpdate?.(track.id, { isVisible: !track.isVisible })}
                  >
                    {track.isVisible ? (
                      <Eye className="h-3 w-3" />
                    ) : (
                      <EyeOff className="h-3 w-3" />
                    )}
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => onTrackUpdate?.(track.id, { isLocked: !track.isLocked })}
                  >
                    <Lock className={`h-3 w-3 ${track.isLocked ? 'text-warning' : ''}`} />
                  </Button>
                  
                  {track.type === 'audio' && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0"
                      onClick={() => onTrackUpdate?.(track.id, { isMuted: !track.isMuted })}
                    >
                      {track.isMuted ? (
                        <VolumeX className="h-3 w-3" />
                      ) : (
                        <Volume2 className="h-3 w-3" />
                      )}
                    </Button>
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-primary truncate">
                    {track.name}
                  </div>
                  <div className="text-xs text-tertiary">
                    {track.type.charAt(0).toUpperCase() + track.type.slice(1)}
                  </div>
                </div>
              </div>

              {/* Track Timeline */}
              <div className="flex-1 relative h-12 bg-surface-primary rounded border border-border-primary overflow-hidden">
                {/* Track Content */}
                <div
                  className="absolute top-1 bottom-1 rounded"
                  style={{
                    left: `${getTrackPosition(track.startTime)}%`,
                    width: `${getTrackWidth(track.duration)}%`,
                    backgroundColor: trackTypeColors[track.type],
                    opacity: track.isVisible ? 1 : 0.5
                  }}
                >
                  <div className="h-full flex items-center px-2">
                    <span className="text-xs text-white font-medium truncate">
                      {track.name}
                    </span>
                  </div>
                  
                  {/* Resize handles */}
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-white opacity-0 hover:opacity-100 cursor-ew-resize" />
                  <div className="absolute right-0 top-0 bottom-0 w-1 bg-white opacity-0 hover:opacity-100 cursor-ew-resize" />
                </div>
              </div>

              {/* Track Actions */}
              <div className="flex items-center gap-1 ml-2">
                <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                  <Scissors className="h-3 w-3" />
                </Button>
                <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                  <Copy className="h-3 w-3" />
                </Button>
                <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-error">
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>
        ))}

        {/* Add Track Button */}
        <Button
          variant="ghost"
          className="w-full h-12 border-2 border-dashed border-border-primary hover:border-brand-primary hover:bg-surface-secondary"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Track
        </Button>
      </div>
    </div>
  );
};

export default ModernTimeline;

