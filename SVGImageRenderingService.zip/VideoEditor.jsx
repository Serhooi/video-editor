import { useState, useRef, useEffect } from 'react'
import { FFmpeg } from '@ffmpeg/ffmpeg'
import { fetchFile, toBlobURL } from '@ffmpeg/util'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Slider } from '@/components/ui/slider.jsx'
import { 
  Upload, 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  Scissors, 
  Type, 
  Palette, 
  Download,
  ZoomIn,
  ZoomOut,
  Monitor,
  Smartphone,
  Square,
  Tv,
  Loader2
} from 'lucide-react'

export default function VideoEditor() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState([80])
  const [zoom, setZoom] = useState([1])
  const [selectedAspectRatio, setSelectedAspectRatio] = useState('16:9')
  const [activeTab, setActiveTab] = useState('edit')
  const [videoFile, setVideoFile] = useState(null)
  const [videoUrl, setVideoUrl] = useState(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [ffmpegLoaded, setFfmpegLoaded] = useState(false)
  
  const fileInputRef = useRef(null)
  const videoRef = useRef(null)
  const ffmpegRef = useRef(new FFmpeg())

  const aspectRatios = [
    { id: '16:9', label: '16:9', icon: Monitor, desc: 'Landscape', ratio: 16/9 },
    { id: '9:16', label: '9:16', icon: Smartphone, desc: 'Portrait', ratio: 9/16 },
    { id: '1:1', label: '1:1', icon: Square, desc: 'Square', ratio: 1 },
    { id: '4:3', label: '4:3', icon: Tv, desc: 'Classic', ratio: 4/3 }
  ]

  const tabs = [
    { id: 'edit', label: 'Edit', icon: Scissors },
    { id: 'text', label: 'Text', icon: Type },
    { id: 'effects', label: 'Effects', icon: Palette }
  ]

  // Initialize FFmpeg
  useEffect(() => {
    const loadFFmpeg = async () => {
      try {
        const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd'
        const ffmpeg = ffmpegRef.current
        
        ffmpeg.on('log', ({ message }) => {
          console.log(message)
        })
        
        await ffmpeg.load({
          coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
          wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
        })
        
        setFfmpegLoaded(true)
        console.log('FFmpeg loaded successfully')
      } catch (error) {
        console.error('Failed to load FFmpeg:', error)
      }
    }
    
    loadFFmpeg()
  }, [])

  const handleFileUpload = (event) => {
    const file = event.target.files[0]
    if (file) {
      setVideoFile(file)
      const url = URL.createObjectURL(file)
      setVideoUrl(url)
    }
  }

  const handleVideoLoad = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration)
    }
  }

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime)
    }
  }

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const handleSeek = (value) => {
    const newTime = (value[0] / 100) * duration
    setCurrentTime(newTime)
    if (videoRef.current) {
      videoRef.current.currentTime = newTime
    }
  }

  const handleVolumeChange = (value) => {
    setVolume(value)
    if (videoRef.current) {
      videoRef.current.volume = value[0] / 100
    }
  }

  const formatTime = (seconds) => {
    if (!seconds || isNaN(seconds)) return '0:00'
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const processVideo = async () => {
    if (!videoFile || !ffmpegLoaded) return
    
    setIsProcessing(true)
    
    try {
      const ffmpeg = ffmpegRef.current
      const inputName = 'input.mp4'
      const outputName = 'output.mp4'
      
      // Write input file
      await ffmpeg.writeFile(inputName, await fetchFile(videoFile))
      
      // Get selected aspect ratio
      const selectedRatio = aspectRatios.find(r => r.id === selectedAspectRatio)
      
      // Process video based on aspect ratio
      let filterArgs = []
      if (selectedAspectRatio !== '16:9') {
        const width = 1280
        const height = Math.round(width / selectedRatio.ratio)
        filterArgs = [
          '-vf', `scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height}`
        ]
      }
      
      // Run FFmpeg command
      await ffmpeg.exec([
        '-i', inputName,
        ...filterArgs,
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-crf', '23',
        outputName
      ])
      
      // Read output file
      const data = await ffmpeg.readFile(outputName)
      const blob = new Blob([data.buffer], { type: 'video/mp4' })
      const url = URL.createObjectURL(blob)
      
      // Download processed video
      const a = document.createElement('a')
      a.href = url
      a.download = `processed_${selectedAspectRatio}_video.mp4`
      a.click()
      
    } catch (error) {
      console.error('Video processing failed:', error)
    } finally {
      setIsProcessing(false)
    }
  }

  const getCurrentAspectRatio = () => {
    return aspectRatios.find(r => r.id === selectedAspectRatio)
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-semibold">VideoEdit Pro</h1>
            <div className="h-6 w-px bg-zinc-700" />
            <span className="text-sm text-zinc-400">Modern Video Editor</span>
          </div>
          <div className="flex items-center space-x-3">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="border-zinc-700 bg-zinc-800 hover:bg-zinc-700"
            >
              <Upload className="mr-2 h-4 w-4" />
              Upload Video
            </Button>
            <Button 
              size="sm"
              onClick={processVideo}
              disabled={!videoFile || !ffmpegLoaded || isProcessing}
              className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
            >
              {isProcessing ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Download className="mr-2 h-4 w-4" />
              )}
              {isProcessing ? 'Processing...' : 'Export'}
            </Button>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-73px)]">
        {/* Sidebar */}
        <aside className="w-80 border-r border-zinc-800 bg-zinc-900/30">
          <div className="p-6">
            {/* Aspect Ratio Selection */}
            <div className="mb-8">
              <h3 className="mb-4 text-sm font-medium text-zinc-300">Aspect Ratio</h3>
              <div className="grid grid-cols-2 gap-3">
                {aspectRatios.map((ratio) => {
                  const Icon = ratio.icon
                  return (
                    <Card 
                      key={ratio.id}
                      className={`cursor-pointer transition-all duration-200 ${
                        selectedAspectRatio === ratio.id 
                          ? 'border-blue-500 bg-blue-500/10' 
                          : 'border-zinc-700 bg-zinc-800/50 hover:border-zinc-600'
                      }`}
                      onClick={() => setSelectedAspectRatio(ratio.id)}
                    >
                      <CardContent className="flex flex-col items-center p-4">
                        <Icon className="mb-2 h-6 w-6" />
                        <div className="text-center">
                          <div className="text-sm font-medium">{ratio.label}</div>
                          <div className="text-xs text-zinc-400">{ratio.desc}</div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>

            {/* Tools Tabs */}
            <div className="mb-6">
              <div className="flex space-x-1 rounded-lg bg-zinc-800 p-1">
                {tabs.map((tab) => {
                  const Icon = tab.icon
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex flex-1 items-center justify-center rounded-md px-3 py-2 text-sm font-medium transition-all ${
                        activeTab === tab.id
                          ? 'bg-blue-600 text-white'
                          : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      <Icon className="mr-2 h-4 w-4" />
                      {tab.label}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Tool Content */}
            <div className="space-y-6">
              {activeTab === 'edit' && (
                <>
                  <div>
                    <label className="mb-3 block text-sm font-medium text-zinc-300">
                      Volume
                    </label>
                    <div className="flex items-center space-x-3">
                      <Volume2 className="h-4 w-4 text-zinc-400" />
                      <Slider
                        value={volume}
                        onValueChange={handleVolumeChange}
                        max={100}
                        step={1}
                        className="flex-1"
                      />
                      <span className="text-sm text-zinc-400">{volume[0]}%</span>
                    </div>
                  </div>
                  
                  <div>
                    <label className="mb-3 block text-sm font-medium text-zinc-300">
                      Timeline Zoom
                    </label>
                    <div className="flex items-center space-x-3">
                      <ZoomOut className="h-4 w-4 text-zinc-400" />
                      <Slider
                        value={zoom}
                        onValueChange={setZoom}
                        min={0.5}
                        max={3}
                        step={0.1}
                        className="flex-1"
                      />
                      <ZoomIn className="h-4 w-4 text-zinc-400" />
                    </div>
                    <div className="mt-2 text-center text-xs text-zinc-400">
                      {zoom[0].toFixed(1)}x
                    </div>
                  </div>

                  {videoFile && (
                    <div className="rounded-lg bg-zinc-800/50 p-4">
                      <h4 className="mb-2 text-sm font-medium text-zinc-300">Video Info</h4>
                      <div className="space-y-1 text-xs text-zinc-400">
                        <div>File: {videoFile.name}</div>
                        <div>Size: {(videoFile.size / 1024 / 1024).toFixed(1)} MB</div>
                        <div>Duration: {formatTime(duration)}</div>
                        <div>Aspect: {selectedAspectRatio}</div>
                      </div>
                    </div>
                  )}
                </>
              )}

              {activeTab === 'text' && (
                <div className="space-y-4">
                  <Button 
                    variant="outline" 
                    className="w-full border-zinc-700 bg-zinc-800 hover:bg-zinc-700"
                  >
                    <Type className="mr-2 h-4 w-4" />
                    Add Text
                  </Button>
                  <div className="text-sm text-zinc-400">
                    Click to add text overlays to your video
                  </div>
                </div>
              )}

              {activeTab === 'effects' && (
                <div className="space-y-4">
                  <Button 
                    variant="outline" 
                    className="w-full border-zinc-700 bg-zinc-800 hover:bg-zinc-700"
                  >
                    <Palette className="mr-2 h-4 w-4" />
                    Add Filter
                  </Button>
                  <div className="text-sm text-zinc-400">
                    Apply visual effects and filters
                  </div>
                </div>
              )}
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col">
          {/* Video Preview */}
          <div className="flex-1 flex items-center justify-center bg-zinc-900/20 p-8">
            <Card className="border-zinc-700 bg-zinc-800/50">
              <CardContent className="p-8">
                {videoUrl ? (
                  <div 
                    className={`relative rounded-lg overflow-hidden ${
                      selectedAspectRatio === '16:9' ? 'aspect-video w-96' :
                      selectedAspectRatio === '9:16' ? 'aspect-[9/16] w-64' :
                      selectedAspectRatio === '1:1' ? 'aspect-square w-80' :
                      'aspect-[4/3] w-96'
                    }`}
                  >
                    <video
                      ref={videoRef}
                      src={videoUrl}
                      className="w-full h-full object-cover"
                      onLoadedMetadata={handleVideoLoad}
                      onTimeUpdate={handleTimeUpdate}
                      onPlay={() => setIsPlaying(true)}
                      onPause={() => setIsPlaying(false)}
                    />
                  </div>
                ) : (
                  <div 
                    className={`bg-zinc-700 rounded-lg flex items-center justify-center text-zinc-400 cursor-pointer hover:bg-zinc-600 transition-colors ${
                      selectedAspectRatio === '16:9' ? 'aspect-video w-96' :
                      selectedAspectRatio === '9:16' ? 'aspect-[9/16] w-64' :
                      selectedAspectRatio === '1:1' ? 'aspect-square w-80' :
                      'aspect-[4/3] w-96'
                    }`}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <div className="text-center">
                      <Upload className="mx-auto mb-4 h-12 w-12" />
                      <p className="text-lg font-medium">Upload a video to start editing</p>
                      <p className="text-sm text-zinc-500 mt-2">
                        Drag and drop or click to select
                      </p>
                      {!ffmpegLoaded && (
                        <p className="text-xs text-yellow-500 mt-2">
                          Loading video processor...
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="border-t border-zinc-800 bg-zinc-900/30 p-6">
            <div className="flex items-center justify-center space-x-4 mb-6">
              <Button 
                variant="outline" 
                size="sm"
                className="border-zinc-700 bg-zinc-800 hover:bg-zinc-700"
                onClick={() => {
                  if (videoRef.current) {
                    videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 10)
                  }
                }}
                disabled={!videoUrl}
              >
                <SkipBack className="h-4 w-4" />
              </Button>
              <Button 
                onClick={togglePlayPause}
                disabled={!videoUrl}
                className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
              >
                {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                className="border-zinc-700 bg-zinc-800 hover:bg-zinc-700"
                onClick={() => {
                  if (videoRef.current) {
                    videoRef.current.currentTime = Math.min(duration, videoRef.current.currentTime + 10)
                  }
                }}
                disabled={!videoUrl}
              >
                <SkipForward className="h-4 w-4" />
              </Button>
            </div>

            {/* Timeline */}
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm text-zinc-400">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
              
              <div className="relative">
                <Slider
                  value={[duration > 0 ? (currentTime / duration) * 100 : 0]}
                  onValueChange={handleSeek}
                  max={100}
                  step={0.1}
                  className="w-full"
                  disabled={!videoUrl}
                />
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={handleFileUpload}
      />
    </div>
  )
}

