import { useState, useRef, useEffect } from 'react'
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core'
import { arrayMove, SortableContext, sortableKeyboardCoordinates, horizontalListSortingStrategy } from '@dnd-kit/sortable'
import { useSortable } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { Slider } from './ui/slider'
import { Button } from './ui/button'
import { Scissors, Copy, Trash2, ZoomIn, ZoomOut } from 'lucide-react'

function SortableTrackItem({ track, currentTime, duration, onTrackClick, onSplitTrack, onCopyTrack, onDeleteTrack }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: track.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  const trackWidth = (track.duration / duration) * 100
  const trackLeft = (track.start / duration) * 100

  return (
    <div className="flex items-center mb-2">
      <div className="w-24 text-sm text-gray-400 flex items-center">
        <div className={`w-3 h-3 rounded-full ${track.color} mr-2`}></div>
        <span className="truncate">{track.name}</span>
      </div>
      <div className="flex-1 h-12 bg-slate-800/50 rounded relative border border-slate-600/50">
        <div
          ref={setNodeRef}
          style={style}
          {...attributes}
          {...listeners}
          className={`absolute top-1 bottom-1 ${track.color} rounded opacity-80 hover:opacity-100 transition-all cursor-grab active:cursor-grabbing flex items-center px-2 group`}
          style={{
            left: `${trackLeft}%`,
            width: `${trackWidth}%`,
            ...style
          }}
          onClick={() => onTrackClick(track)}
        >
          <span className="text-xs text-white font-medium truncate flex-1">
            {track.name}
          </span>
          
          {/* Track Controls */}
          <div className="opacity-0 group-hover:opacity-100 transition-opacity flex space-x-1 ml-2">
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-white hover:bg-white/20"
              onClick={(e) => {
                e.stopPropagation()
                onSplitTrack(track.id, currentTime)
              }}
            >
              <Scissors className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-white hover:bg-white/20"
              onClick={(e) => {
                e.stopPropagation()
                onCopyTrack(track.id)
              }}
            >
              <Copy className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-white hover:bg-white/20"
              onClick={(e) => {
                e.stopPropagation()
                onDeleteTrack(track.id)
              }}
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export function Timeline({ 
  tracks, 
  setTracks, 
  currentTime, 
  setCurrentTime, 
  duration, 
  zoomLevel, 
  setZoomLevel,
  selectedTrack,
  setSelectedTrack 
}) {
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  )

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const generateTimeMarkers = () => {
    const markers = []
    const totalSeconds = duration
    const interval = Math.max(1, Math.floor(10 / zoomLevel))
    
    for (let i = 0; i <= totalSeconds; i += interval) {
      markers.push(
        <div key={i} className="flex flex-col items-center text-xs text-gray-400">
          <div className="w-px h-3 bg-gray-600"></div>
          <span className="mt-1">{formatTime(i)}</span>
        </div>
      )
    }
    return markers
  }

  const handleDragEnd = (event) => {
    const { active, over } = event

    if (active.id !== over?.id) {
      setTracks((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id)
        const newIndex = items.findIndex((item) => item.id === over.id)
        return arrayMove(items, oldIndex, newIndex)
      })
    }
  }

  const handleTrackClick = (track) => {
    setSelectedTrack(track.id === selectedTrack?.id ? null : track)
  }

  const handleSplitTrack = (trackId, splitTime) => {
    setTracks(prevTracks => {
      const trackIndex = prevTracks.findIndex(t => t.id === trackId)
      if (trackIndex === -1) return prevTracks
      
      const track = prevTracks[trackIndex]
      const splitPoint = splitTime - track.start
      
      if (splitPoint <= 0 || splitPoint >= track.duration) return prevTracks
      
      const newTracks = [...prevTracks]
      const firstPart = {
        ...track,
        id: Date.now() + Math.random(),
        duration: splitPoint,
        name: `${track.name} (1)`
      }
      const secondPart = {
        ...track,
        id: Date.now() + Math.random() + 1,
        start: track.start + splitPoint,
        duration: track.duration - splitPoint,
        name: `${track.name} (2)`
      }
      
      newTracks.splice(trackIndex, 1, firstPart, secondPart)
      return newTracks
    })
  }

  const handleCopyTrack = (trackId) => {
    setTracks(prevTracks => {
      const track = prevTracks.find(t => t.id === trackId)
      if (!track) return prevTracks
      
      const newTrack = {
        ...track,
        id: Date.now() + Math.random(),
        start: track.start + track.duration + 1,
        name: `${track.name} (Copy)`
      }
      
      return [...prevTracks, newTrack]
    })
  }

  const handleDeleteTrack = (trackId) => {
    setTracks(prevTracks => prevTracks.filter(t => t.id !== trackId))
    if (selectedTrack?.id === trackId) {
      setSelectedTrack(null)
    }
  }

  return (
    <div className="bg-slate-900/80 backdrop-blur-sm border-t border-slate-700/50 p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-200">Timeline</h3>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setZoomLevel(Math.max(0.1, zoomLevel - 0.2))}
              className="text-gray-400 hover:text-white"
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm text-gray-400 w-12 text-center">{zoomLevel.toFixed(1)}x</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setZoomLevel(Math.min(5, zoomLevel + 0.2))}
              className="text-gray-400 hover:text-white"
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Time Markers */}
      <div className="flex justify-between mb-2 px-2 overflow-x-auto">
        {generateTimeMarkers()}
      </div>

      {/* Tracks */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <SortableContext items={tracks.map(t => t.id)} strategy={horizontalListSortingStrategy}>
          <div className="space-y-2 min-h-32">
            {tracks.map((track) => (
              <SortableTrackItem
                key={track.id}
                track={track}
                currentTime={currentTime}
                duration={duration}
                onTrackClick={handleTrackClick}
                onSplitTrack={handleSplitTrack}
                onCopyTrack={handleCopyTrack}
                onDeleteTrack={handleDeleteTrack}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>

      {/* Playhead */}
      <div className="relative mt-4">
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10 pointer-events-none"
          style={{ left: `${(currentTime / duration) * 100}%` }}
        >
          <div className="absolute -top-2 -left-2 w-4 h-4 bg-red-500 rounded-full"></div>
        </div>
        <Slider
          value={[currentTime]}
          onValueChange={(value) => setCurrentTime(value[0])}
          max={duration}
          step={0.1}
          className="w-full"
        />
      </div>

      {/* Selected Track Info */}
      {selectedTrack && (
        <div className="mt-4 p-3 bg-slate-800/50 rounded border border-slate-600/50">
          <h4 className="text-sm font-medium text-gray-300 mb-2">Selected Track</h4>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <span className="text-gray-500">Name:</span>
              <p className="text-gray-300">{selectedTrack.name}</p>
            </div>
            <div>
              <span className="text-gray-500">Duration:</span>
              <p className="text-gray-300">{formatTime(selectedTrack.duration)}</p>
            </div>
            <div>
              <span className="text-gray-500">Start:</span>
              <p className="text-gray-300">{formatTime(selectedTrack.start)}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

