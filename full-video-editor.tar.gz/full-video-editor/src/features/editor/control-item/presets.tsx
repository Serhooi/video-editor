const Presets = () => {
  return (
    <div className="flex flex-1 flex-col">
      <div className="text-md text-text-primary flex h-12 flex-none items-center px-4 font-medium">
        Presets
      </div>
    </div>
  );
};

export default Presets;
