import Draggable from "@/components/shared/draggable";
import { ScrollArea } from "@/components/ui/scroll-area";
import { TRANSITIONS } from "../data/transitions";
import { dispatch } from "@designcombo/events";
import { ADD_TRANSITION } from "@designcombo/state";
import { WandSparkles } from "lucide-react";
import { useIsDraggingOverTimeline } from "../hooks/is-dragging-over-timeline";
import React from "react";
import { generateId } from "@designcombo/timeline";

export const Transitions = () => {
  const isDraggingOverTimeline = useIsDraggingOverTimeline();

  const handleAddTransition = (payload: any) => {
    payload.id = generateId();
    dispatch(ADD_TRANSITION, {
      payload,
      options: {},
    });
  };

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-border/80 p-4">
        <div className="flex items-center gap-2">
          <WandSparkles size={20} />
          <h2 className="text-lg font-semibold">Transitions</h2>
        </div>
        <p className="text-sm text-muted-foreground">
          Drag transitions to timeline
        </p>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="grid grid-cols-2 gap-2 p-4">
          {TRANSITIONS.map((transition) => (
            <Draggable
              key={transition.id}
              data={() => ({
                type: 'transition',
                id: transition.id,
                kind: transition.kind,
                duration: transition.duration,
                preview: transition.preview,
                name: transition.name,
                direction: transition.direction,
              })}
              onDrop={() => {
                if (isDraggingOverTimeline) {
                  handleAddTransition({
                    type: 'transition',
                    kind: transition.kind,
                    duration: transition.duration,
                    preview: transition.preview,
                    name: transition.name,
                    direction: transition.direction,
                  });
                }
              }}
            >
              <div className="group cursor-grab active:cursor-grabbing">
                <div className="aspect-video rounded-lg overflow-hidden bg-gray-100 border border-gray-200 hover:border-blue-300 transition-colors">
                  <img
                    src={transition.preview}
                    alt={transition.name || transition.kind}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      // Fallback if image fails to load
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                      target.parentElement!.innerHTML = `
                        <div class="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-400 to-blue-500 text-white text-xs font-medium">
                          ${transition.name || transition.kind}
                        </div>
                      `;
                    }}
                  />
                </div>
                <div className="mt-2 text-center">
                  <div className="text-sm font-medium text-gray-900">
                    {transition.name || transition.kind}
                  </div>
                  <div className="text-xs text-gray-500">
                    {transition.duration}s
                  </div>
                </div>
              </div>
            </Draggable>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

